"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useParams } from "next/navigation";

/* ---------- utils ---------- */
function formatThaiDate(input) {
  if (!input) return "";
  const d = new Date(input);

  const months = [
    "มกราคม",
    "กุมภาพันธ์",
    "มีนาคม",
    "เมษายน",
    "พฤษภาคม",
    "มิถุนายน",
    "กรกฎาคม",
    "สิงหาคม",
    "กันยายน",
    "ตุลาคม",
    "พฤศจิกายน",
    "ธันวาคม",
  ];

  return `${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear() + 543}`;
}

export default function publicDetail() {
  const { id } = useParams();

  const [data, setData] = useState(null);
  const [openImage, setOpenImage] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(`/ppdhome/api/public/${id}`);
        if (!res.ok) {
          setData(null);
          return;
        }

        const json = await res.json();
        setData(json);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    if (id) load();
  }, [id]);

  if (loading) {
    return (
      <p className="text-center mt-20 text-gray-500">
        กำลังโหลดข้อมูล...
      </p>
    );
  }

  if (!data) {
    return (
      <p className="text-center mt-20 text-red-500">
        ไม่พบข้อมูล
      </p>
    );
  }

  const images = data.image ? data.image.split(",") : [];

  return (
    <section className="lg:mx-20 md:mx-9 mx-5 bg-pink-100 rounded-xl lg:p-10 md:p-6 p-4">
      <p className="lg:text-4xl md:text-3xl text-xl font-semibold text-center text-shadow-lg">
        {data.title}
      </p>

      {data.subtitle && (
        <p className="lg:mt-5 mt-2 lg:text-4xl md:text-3xl text-xl font-semibold text-center text-shadow-lg">
          {data.subtitle}
        </p>
      )}

      {data.header_date && (
        <p className="lg:mt-5 mt-2 lg:text-4xl md:text-3xl text-xl font-semibold text-center text-shadow-lg">
          {data.header_date}
        </p>
      )}
      <p className="mt-5 md:text-base text-sm">
        {formatThaiDate(data.content_date)}
      </p>
      <p className="mt-5 md:text-base text-sm whitespace-pre-line">
        {data.detail}
      </p>

      {images.length > 0 && (
        <div className="grid md:grid-cols-5 grid-cols-2 md:gap-6 gap-4 md:mt-8 mt-4">
          {images.map((img, index) => (
            <div
              key={index}
              className="relative w-full aspect-[5/4] overflow-hidden bg-gray-100"
            >
              <Image
                src={img}
                alt={`รูปข่าว ${index + 1}`}
                fill
                className="object-cover cursor-pointer transition duration-300 hover:scale-105"
                onClick={() => setOpenImage(img)}
              />
            </div>
          ))}
        </div>
      )}

      {openImage && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center"
          onClick={() => setOpenImage(null)}
        >
          <div
            className="relative max-w-5xl w-full mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpenImage(null)}
              className="absolute -top-10 right-0 text-white text-3xl"
            >
              ✕
            </button>

            <Image
              src={openImage}
              alt="ภาพขยาย"
              width={1200}
              height={800}
              className="rounded-lg object-contain w-full h-auto"
            />
          </div>
        </div>
      )}
    </section>
  );
}
