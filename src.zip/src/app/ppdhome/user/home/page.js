"use client";
import Image from "next/image";
import Link from "next/link";
import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import {
  PieChart,
  Pie,
  ResponsiveContainer,
  Cell,
} from "recharts";

const data = [
  { name: "เพศหญิง", value: 1042591 },
  { name: "เพศชาย", value: 1122536 },
];

const COLORS = ["#F9BED8", "#88B7F1"];

export default function HomePage() {
  const videoRef = useRef(null);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          video.play().catch(() => { });
        } else {
          video.pause();
        }
      },
      { threshold: 0.6 }
    );

    observer.observe(video);

    return () => observer.disconnect();
  }, []);


  const { scrollY } = useScroll();
  const [open, setOpen] = useState(null);

  const Menu = (name) => {
    setOpen((prev) => (prev === name ? null : name));
  };

  const opacityProfile = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <div className="flex min-h-screen font-sans">
      <main className="relative flex min-h-screen w-full flex-col sm:items-start bg-cover lg:mx-20 md:mx-10 mx-4">

        <section className="relative flex flex-col z-10 bg-pink-50 px-6 rounded-t-xl lg:mt-0 md:mt-4 w-full xl:px-30">
          <motion.div initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, amount: 0.4 }}>

            <div className="flex justify-between flex-col md:flex-row rounded-xl lg:h-120">
              <div className="relative overflow-hidden xl:mt-5 md:mt-8 mt-4 xl:h-[550px] xl:w-[550px] md:h-[260px] md:w-[260px] h-[200px] w-[280px]">
                <Image
                  src="/pic/ppdhome.JPG"
                  alt="รูปสถาบัน"
                  fill
                  sizes="(max-width: 768px) 100vw, 550px"
                  priority
                  quality={75}
                  className="object-cover xl:rounded-b-full xl:rounded-none md:rounded-full rounded-xl"
                />

              </div>

              <div className="flex flex-col md:text-right x:mt-12 xl:ms-10 md:mt-8 mt-4">
                <p className="xl:text-4xl md:text-3xl text-xl font-semibold text-shadow-lg">สถานคุ้มครองและพัฒนาคนพิการ</p>
                <p className="xl:text-4xl md:text-3xl text-xl font-semibold text-shadow-lg">พระประแดง จ.สมุทรปราการ</p>
                <p className="xl:mt-18 lg:text-xl text-sm md:mt-8 mt-4" >สถานคุ้มครองและพัฒนาคนพิการ พระประแดง</p>
                <p className="lg:text-xl text-sm">ก่อตั้งขึ้นเพื่อเป็นศูนย์กลางด้านการคุ้มครอง ฟื้นฟู และพัฒนาคนพิการ</p>
                <p className="xl:mt-10 md:mt-6 mt-4 lg:text-xl text-sm" >โดยมุ่งเน้นการเสริมสร้างศักยภาพและคุณภาพชีวิตให้ดียิ่งขึ้น</p>
                <div className="xl:flex xl:justify-end">

                  <Link
                    href="/ppdhome/user/aboutAll/about"
                  >
                    <button className="p-3 border border-pink-700 hover:bg-pink-700 md:text-lg text-xs text-pink-700 hover:text-white shadow-md shadow-pink-700/25 rounded-3xl transition xl:mt-10 md:mt-6 mt-4 xl:mb-0 mb-4">
                      คลิ๊กเพื่ออ่านเพิ่มเติม
                    </button>
                  </Link>

                </div>
              </div>
            </div>
          </motion.div>
        </section>

        <section className="relative flex flex-col bg-pink-50 lg:px-15 px-6 rounded-b-xl mt-2 w-full xl:px-30">
          <motion.div
            className="relative z-30" initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, amount: 0.7 }}>
            <div className="flex justify-between flex-col md:flex-row rounded-xl lg:h-110 xl:gap-10">
              <div className="relative overflow-hidden md:hidden xl:h-[500px] xl:w-[430px] md:h-[250px] md:w-[300px] h-[200px] w-[280px] mt-5 xl:ms-0">
                <Image src="/pic/product.JPG"
                  fill
                  alt="รูปผลิตภัณฑ์ฝีมือคนพิการ"
                  sizes="(max-width: 768px) 100vw, 550px"
                  quality={75}
                  className="object-cover xl:rounded-b-full xl:rounded-none md:rounded-full rounded-xl" />
              </div>
              <div className="flex flex-col xl:mt-15 xl:pt-15 md:mt-10 mt-4">
                <p className="md:text-2xl text-xl font-semibold text-shadow-lg">ผลิตภัณฑ์ฝีมือคนพิการ “จักสานย่านลิเภา”</p>
                <p className="md:mt-8 mt-4 md:text-lg text-sm" >ผลงานของผู้พิการที่ฝึกอาชีพในสถานฯ ถ่ายทอด ความประณีต ความตั้งใจ และคุณค่าแห่งการพึ่งพา ตนเอง</p>
                <p className="mt-1 md:text-lg text-sm" >ผลิตภัณฑ์แต่ละชิ้นคือสัญลักษณ์ของโอกาสและศักดิ์ศรีในชีวิต</p>
                <div className="xl:flex xl:justify-end">
                  <Link
                    href="/ppdhome/user/product"
                  >
                    <button className="p-3 xl:mt-8 mt-6 xl:mb-0 mb-6 border border-pink-700 hover:bg-pink-700 md:text-lg text-xs text-pink-700 hover:text-white shadow-md shadow-pink-700/25 rounded-3xl transition">
                      คลิ๊กเพื่ออ่านเพิ่มเติม
                    </button>
                  </Link>
                </div>

              </div>
              <div className="relative overflow-hidden hidden md:block xl:h-[500px] xl:w-[430px] h-[250px] w-[300px] mt-5 md:mb-4 lg:mb-0">
                <Image src="/pic/product.JPG" fill alt="รูปผลิตภัณฑ์ฝีมือคนพิการ" className="object-cover xl:rounded-b-full xl:rounded-none rounded-full" />
              </div>
            </div>
          </motion.div>
        </section>


        <section className="relative flex flex-col bg-pink-50 lg:px-15 px-6 rounded-b-xl mt-2 w-full xl:px-30">
          <motion.div
            className="relative z-30" initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true, amount: 0.7 }}>
            <div className="flex justify-between flex-col md:flex-row rounded-xl lg:h-110">
              <div className="relative overflow-visible z-20 xl:-mt-20 md:mt-10 mt-4 xl:h-[500px] xl:w-[430px] md:h-[260px] md:w-[300px] h-[200px] w-[280px]">
                <Image src="/pic/exercise.JPG"
                  fill
                  alt="รูปออกกำลังกาย"
                  sizes="(max-width: 768px) 100vw, 550px"
                  priority
                  quality={75}
                  className="object-cover xl:rounded-t-full xl:rounded-none md:rounded-full rounded-xl" />
              </div>
              <div className="flex flex-col text-right xl:mt-15 xl:pt-15 md:mt-10 mt-4">
                <p className="md:text-2xl text-xl font-semibold text-shadow-lg">การฟื้นฟูสมรรถภาพทางการแพทย์</p>
                <p className="md:mt-8 mt-4 md:text-lg text-sm" >เราให้บริการดูแลและฟื้นฟูสุขภาพผู้พิการอย่างต่อเนื่องโดยทีมพยาบาลและเจ้าหน้าที่สาธารณสุขตลอด 24 ชั่วโมง</p>
                <p className="mt-1 md:text-lg text-sm" >พร้อมกิจกรรมเสริมสุขภาพ เช่น ตรวจสุขภาพประจำปี ฉีดวัคซีน และให้คำปรึกษา ด้านโภชนาการ</p>
                <p className="mt-1 md:text-lg text-sm" >เพื่อให้ทุกคนมีสุขภาพที่แข็งแรง ทั้งกายและใจ </p>
                <div className="xl:flex xl:justify-end">
                  <Link
                    href="/ppdhome/user/services/sport"
                  >
                    <button className="p-3 xl:mt-8 mt-6 xl:mb-0 mb-6 border border-pink-700 hover:bg-pink-700 md:text-lg text-xs text-pink-700 hover:text-white shadow-md shadow-pink-700/25 rounded-3xl transition">
                      คลิ๊กเพื่ออ่านเพิ่มเติม
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        <div className="w-full max-w-4xl mx-auto xl:mt-16 md:mt-8 mt-4">
          <p className="xl:text-5xl md:text-3xl text-lg font-semibold text-center">
            กิจกรรมอาชีวบำบัด ตะกร้าสานพลาสติก
          </p>

          <video
            ref={videoRef}
            muted              // ต้องมีเพื่อ auto play
            controls           // ให้กดหยุด / เล่น / เปิดเสียงได้
            playsInline
            preload="metadata"
            className="w-full aspect-video rounded-2xl shadow-xl object-cover xl:mt-6 md:mt-4 mt-2"
          >
            <source src="/video/คลิปสานตะกร้า.mov" type="video/mp4" />
          </video>
        </div>

        <section className="relative flex flex-col z-10 xl:pb-20 md:pb-8 xl:mt-10 mt-2 w-full bg-transparent">
          <div className="relative flex flex-col bg-pink-100 md:mt-10 mt-4 shadow-md rounded-xl md:pt-8 pt-4 xl:px-10 px-4 z-10 pb-8 md:pb-16 xl:pb-20">
            <div className="flex justify-center text-center">
              <p className="xl:text-5xl md:text-3xl text-lg font-semibold text-shadow-lg">
                รายงานข้อมูลสถานการณ์ด้านคนพิการในประเทศไทย
              </p>
            </div>
            <p className="xl:text-2xl xl:text-right md:text-left text-center mt-2 md:mt-4 xl:mt-12 xl:ms-0 ms-4 xl:me-30 font-light md:text-xl text-sm" >
              ข้อมูล ณ วันที่ 1 เดือนกุมภาพันธ์พ.ศ. 2567
            </p>

            <div className="flex xl:justify-end items-end xl:text-right mt-2 xl:mt-5 md:me-42 xl:ms-0 md:ms-4 ms-2">
              <p className="xl:text-2xl md:text-xl text-sm font-light">คนพิการทั่วประเทศ</p>
              <p className="xl:text-4xl md:text-3xl text-sm md:ms-6 ms-2 font-semibold text-pink-700">
                2,165,127
              </p>
            </div>
            <div className="relative">
              <div className="absolute md:ms-80 ms-40 xl:-top-40 md:-top-20 -top-6">
                <div className="xl:w-[350px] xl:h-[350px] md:w-[300px] md:h-[250px] w-[150px] h-[150px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={data}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        startAngle={90}
                        endAngle={450}
                      >
                        {data.map((entry, idx) => (
                          <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              <div className="flex xl:justify-end md:items-end md:text-right md:me-42 mt-10">
                <div className="flex flex-col gap-3 md:text-xl text-sm font-medium md:ms-20">
                  {data.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-5 md:text-2xl text-ms">
                      <span
                        className="w-5 h-5 rounded-sm"
                        style={{ backgroundColor: COLORS[idx] }}
                      />
                      <div className="flex">
                        <span className="font-light">{item.name}</span>
                        <span className="md:ms-6 ms-3 font-semibold text-pink-700">
                          {item.value.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>


        <section className="relative flex flex-col w-full bg-transparent py-5 xl:mb-10">
          <div className="relative flex flex-col items-center bg-pink-100 shadow-md rounded-xl md:py-10 py-6">
            <p className="text-xl md:text-3xl xl:text-5xl font-semibold text-shadow-lg text-center md:px-0 px-4">
              ผู้ปกครองสถานคุ้มครองและพัฒนาคนพิการ พระประแดง
            </p>

            <div className="relative w-full flex justify-center md:mt-10 mt-4">

              <div className="absolute top-1/2 -translate-y-1/2 w-[90%] h-[70%] bg-pink-200 rounded-[40px]"></div>

              <div className="relative bg-white md:w-[50%] w-[60%] md:rounded-[40px] rounded-xl md:px-10 px-4 md:pt-10 pt-4 pb-8 flex flex-col items-center z-10 shadow-md">
                <Image
                  src="/pic/parent.jpeg"
                  alt="รูปผู้ปกครองสถานคุ้มครอง"
                  width={260}
                  height={300}
                  className="object-cover rounded-md"
                />
                <p className="mt-6 md:text-xl font-light text-sm">ว่าที่ร้อยตรีณัทกร ธงสอาด</p>
              </div>
            </div>
          </div>
        </section>


      </main>
    </div>
  );
}
