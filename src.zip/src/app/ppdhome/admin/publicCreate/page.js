"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function CreatePublicPage() {
  const router = useRouter();

  /* ===== utils ===== */
  const getNowLocal = () => {
    const now = new Date();
    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  };

  /* ===== state ===== */
  const [form, setForm] = useState({
    title: "",
    subtitle: "",
    header_date: "",
    content_date: "",
    detail: "",
  });

  const [maxDate, setMaxDate] = useState("");
  const [files, setFiles] = useState([]);
  const [pdfFile, setPdfFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  /* ===== set datetime max ===== */
  useEffect(() => {
    setMaxDate(getNowLocal());
  }, []);

  /* ===== handlers ===== */
  function handleChange(e) {
    const { name, value } = e.target;

    if (name === "content_date") {
      const now = getNowLocal();
      if (value > now) {
        setForm((prev) => ({ ...prev, content_date: now }));
        return;
      }
    }

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  }

  const handleFileChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    if (!selectedFiles.length) return;
    setFiles((prev) => [...prev, ...selectedFiles]);
  };

  const handlePdfChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (file.type !== "application/pdf") {
      alert("กรุณาเลือกไฟล์ PDF เท่านั้น");
      return;
    }

    setPdfFile(file);
  };

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    const formData = new FormData();
    formData.append("title", form.title);
    formData.append("subtitle", form.subtitle);
    formData.append("header_date", form.header_date);
    formData.append("content_date", form.content_date);
    formData.append("detail", form.detail);

    files.forEach((file) => {
      formData.append("images", file);
    });

    if (pdfFile) {
      formData.append("pdf", pdfFile);
    }

    const res = await fetch("/ppdhome/api/public", {
      method: "POST",
      body: formData,
    });

    if (res.ok) {
      alert("เพิ่มประกาศสำเร็จ");
      router.push("/ppdhome/admin/newsAndPublicCreate");
      return;
    }

    const data = await res.json();
    setMessage("เกิดข้อผิดพลาด: " + data.error);
    setLoading(false);
  }

  /* ===== render ===== */
  return (
    <div className="lg:mx-20 md:mx-10 mx-4 p-6 border lg:mt-14 md:mt-6 mt-4 lg:py-10 md:py-6 py-4 lg:px-15 md:px-10 px-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        
        {/* ===== หัวข้อ ===== */}
        <div className="flex lg:gap-40 md:gap-10 md:flex-row flex-col">
          <label className="block">
            <span className="block mb-1 font-medium lg:text-2xl md:text-xl text-lg">
              ชื่อหัวข้อ
            </span>
            <input
              name="title"
              placeholder="ชื่อหัวข้อ"
              value={form.title}
              onChange={handleChange}
              required
              className="lg:w-120 w-70 border p-2 rounded"
            />
          </label>

          <label className="block">
            <span className="block mb-1 font-medium lg:text-2xl md:text-xl text-lg md:mt-0 mt-4">
              ชื่อหัวข้อ 2 (ถ้ามี)
            </span>
            <input
              name="subtitle"
              placeholder="ชื่อหัวข้อ 2"
              value={form.subtitle}
              onChange={handleChange}
              className="lg:w-120 w-70 border p-2 rounded"
            />
          </label>
        </div>

        {/* ===== วันที่ ===== */}
        <div className="flex lg:gap-40 md:gap-10 md:flex-row flex-col">
          <label className="block">
            <span className="block mb-1 font-medium lg:text-2xl md:text-xl text-lg">
              ครั้งที่ (ถ้ามี)
            </span>
            <input
              name="header_date"
              placeholder="ex. ครั้งที่ 00/2569"
              value={form.header_date}
              onChange={handleChange}
              className="lg:w-120 w-70 border p-2 rounded"
            />
          </label>

          <label className="block">
            <span className="block mb-1 font-medium lg:text-2xl md:text-xl text-lg md:mt-0 mt-4">
              วันที่และเวลา
            </span>
            <input
              type="datetime-local"
              name="content_date"
              value={form.content_date}
              max={maxDate}
              onChange={handleChange}
              className="lg:w-120 w-70 border p-2 rounded"
            />
          </label>
        </div>

        {/* ===== รายละเอียด ===== */}
        <label className="block">
          <span className="block mb-1 font-medium lg:text-2xl md:text-xl text-lg">
            เพิ่มรายละเอียด
          </span>
          <textarea
            name="detail"
            placeholder="รายละเอียดประกาศ"
            value={form.detail}
            onChange={handleChange}
            rows={5}
            className="lg:w-120 w-70 border p-2 rounded"
          />
        </label>

        {/* ===== PDF ===== */}
        <div className="block mt-6">
          <span className="block mb-2 font-medium lg:text-2xl md:text-xl text-lg">
            เพิ่มไฟล์ PDF (ถ้ามี)
          </span>

          {pdfFile ? (
            <div className="flex items-center gap-4 border p-3 rounded-md w-fit">
              <span className="text-sm">{pdfFile.name}</span>
              <button
                type="button"
                onClick={() => setPdfFile(null)}
                className="bg-red-500 text-white px-3 py-1 rounded text-sm"
              >
                ลบ
              </button>
            </div>
          ) : (
            <label className="w-[220px] h-[60px] border rounded-md flex items-center justify-center cursor-pointer hover:border-pink-700 transition">
              <input
                type="file"
                accept="application/pdf"
                className="hidden"
                onChange={handlePdfChange}
              />
              <span className="text-sm">เลือกไฟล์ PDF</span>
            </label>
          )}
        </div>

        {/* ===== รูปภาพ ===== */}
        <div className="block">
          <span className="block mb-2 font-medium lg:text-2xl md:text-xl text-lg">
            เพิ่มรูป
          </span>

          <div className="flex gap-3 flex-wrap">
            {files.map((file, index) => (
              <div key={index} className="w-[220px] h-[140px] rounded-md overflow-hidden relative">
                <img
                  src={URL.createObjectURL(file)}
                  alt="preview"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() =>
                    setFiles((prev) => prev.filter((_, i) => i !== index))
                  }
                  className="absolute top-1 right-1 bg-black/60 text-white text-sm px-2 rounded"
                >
                  ✕
                </button>
              </div>
            ))}

            <label className="w-[220px] h-[140px] border rounded-md flex items-center justify-center cursor-pointer hover:border-pink-700 transition">
              <input
                type="file"
                accept="image/png, image/jpeg"
                multiple
                className="hidden"
                onChange={handleFileChange}
              />
              <span className="text-4xl font-light">+</span>
            </label>
          </div>
        </div>

        {/* ===== Submit ===== */}
        <div className="flex items-end justify-end">
          <button
            type="submit"
            disabled={loading}
            className="bg-pink-700 text-white px-8 py-2 rounded-xl hover:bg-pink-800"
          >
            {loading ? "Saving..." : "save"}
          </button>
        </div>
      </form>

      {message && <p className="mt-4 font-medium">{message}</p>}
    </div>
  );
}
