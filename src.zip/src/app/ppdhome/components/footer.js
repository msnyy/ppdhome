"use client";
import Image from "next/image";
import Link from "next/link";
import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";

export default function Footer() {
    const [visitor, setVisitor] = useState({ total: 0, today: 0 });


    useEffect(() => {

    // 🔥 ยิง POST เพื่อเพิ่มยอด (ไม่รอผล)
    fetch("/ppdhome/api/visitor", {
        method: "POST",
        keepalive: true
    });

    // 🔥 ดึงข้อมูลมาแสดง
    fetch("/ppdhome/api/visitor")
        .then(res => res.json())
        .then(data => setVisitor(data));

}, []);



    const pathname = usePathname();
    if (pathname === "/ppdhome/admin/login") return null;
    if (pathname === "/ppdhome/admin/allCreate") return null;

    return (
        <footer>
            <section className="bg-pink-100 p-8 md:px-12 xl:m-10 md:m-8 m-4 xl:mx-20 rounded-3xl">
                <div>
                    <Link href="./home" className="flex items-center gap-3">
                        <Image src="/pic/logo.png" alt="ตราสถาบัน" width={700} height={200} />
                    </Link>
                </div>

                <div className="flex justify-between mt-4 md:mt-12">
                    <div>
                        <div className="md:text-base text-xs">
                            <p>ที่ตั้ง : </p>
                            <p>เลขที่ 374 ถนนศรีเขื่อนขันธ์ ตำบลตลาด อำเภอพระประแดง จังหวัดสมุทรปราการ 10130</p>
                        </div>
                        <div className="mt-4 md:mt-8 md:text-base text-xs">
                            <p>โทรศัพท์: 0-2462-5232</p>
                        </div>
                        <div className="mt-4 md:mt-8 md:text-base text-xs">
                            <p>อีเมล:</p>
                            <p>bpd.dep374@gmail.com, </p>
                            <p>
                                baanphrapradaeng@dep.go.th
                            </p>

                            <Link
                                href="/ppdhome/admin/login"
                                className="block mt-6 text-xs hover:text-gray-700"
                            >
                                สำหรับเจ้าหน้าที่
                            </Link>

                        </div>
                        <div className="md:hidden text-xs mt-4">
                            <p>Today's visitors: {visitor.todayViews}</p>
                            <p>Total visitors: {visitor.totalViews}</p>
                        </div>
                    </div>
                    <div>
                        <div className="md:text-base hidden md:block">
                            <p>Today's visitors: {visitor.todayViews}</p>
                            <p>Total visitors: {visitor.totalViews}</p>
                        </div>
                        <div className="flex md:mt-30 mt-42 md:gap-2">
                            <a href={"https://www.facebook.com/profile.php?id=61556123048228"} className="flex hover:text-rose-700">
                                <svg className="md:w-12 md:h-10 w-10 h-8" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="30" height="24" fill="currentColor" viewBox="0 0 24 24">
                                    <path fillRule="evenodd" d="M13.135 6H15V3h-1.865a4.147 4.147 0 0 0-4.142 4.142V9H7v3h2v9.938h3V12h2.021l.592-3H12V6.591A.6.6 0 0 1 12.592 6h.543Z" clipRule="evenodd" />
                                </svg>
                            </a>
                            <a href={"https://www.tiktok.com/@._dep3?_t=ZS-8upw3waHByR&_r=1"} className="flex hover:text-rose-700 mt-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" className="bi bi-tiktok md:w-8 md:h-8 w-7 h-6" viewBox="0 0 16 16">
                                    <path d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3z" />
                                </svg>
                            </a>

                        </div>
                    </div>
                </div>
            </section>
        </footer>

    );
}