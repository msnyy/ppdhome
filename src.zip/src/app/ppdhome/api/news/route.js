import sql from "mssql";
import path from "path";
import { mkdir, writeFile } from "fs/promises";
import { getPool } from "@lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ===================== GET : NEWS ===================== */
export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);

    const page = Number(searchParams.get("page") || 1);
    const pageSize = Number(searchParams.get("pageSize") || 10);
    const offset = (page - 1) * pageSize;

    const pool = await getPool();

    const totalResult = await pool
      .request()
      .query(`SELECT COUNT(*) AS total FROM dbo.news`);

    const result = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("pageSize", sql.Int, pageSize)
      .query(`
        SELECT
          id,
          title,
          subtitle,
          header_date,
          content_date,
          pdf_file
        FROM dbo.news
        ORDER BY content_date DESC, id DESC
        OFFSET @offset ROWS
        FETCH NEXT @pageSize ROWS ONLY
      `);

    return Response.json({
      items: result.recordset,
      total: totalResult.recordset[0].total,
    });
  } catch (error) {
    console.error("NEWS API ERROR 👉", error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

/* ===================== POST : NEWS ===================== */
export async function POST(request) {
  try {
    const formData = await request.formData();

    const title = formData.get("title");
    const subtitle = formData.get("subtitle");
    const header_date = formData.get("header_date");
    const content_date = formData.get("content_date");
    const detail = formData.get("detail");

    const sqlDate = content_date
      ? content_date.replace("T", " ")
      : null;

    const pdf = formData.get("pdf");
    let pdfPath = null;

    if (pdf && pdf.name) {
      const uploadDir = path.join(
        process.cwd(),
        "public/uploads/news"
      );

      await mkdir(uploadDir, { recursive: true });

      const buffer = Buffer.from(await pdf.arrayBuffer());
      const fileName = `${Date.now()}-${pdf.name}`;
      await writeFile(path.join(uploadDir, fileName), buffer);

      pdfPath = `/uploads/news/${fileName}`;
    }

    const pool = await getPool();

    await pool.request()
      .input("title", sql.NVarChar, title)
      .input("subtitle", sql.NVarChar, subtitle)
      .input("header_date", sql.NVarChar, header_date)
      .input("content_date", sql.DateTime, sqlDate)
      .input("detail", sql.NVarChar, detail)
      .input("pdf_file", sql.NVarChar, pdfPath)
      .query(`
        INSERT INTO dbo.news (
          title,
          subtitle,
          header_date,
          content_date,
          detail,
          pdf_file
        )
        VALUES (
          @title,
          @subtitle,
          @header_date,
          @content_date,
          @detail,
          @pdf_file
        )
      `);

    return Response.json(
      { message: "เพิ่มข่าวสำเร็จ" },
      { status: 201 }
    );

  } catch (error) {
    console.error("POST NEWS ERROR 👉", error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
