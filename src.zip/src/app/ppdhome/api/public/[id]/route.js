import sql from "mssql";
import { getPool } from "@lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/* ===================== GET : ข่าวตาม id ===================== */
export async function GET(request) {
  try {
    const url = new URL(request.url);
    const idStr = url.pathname.split("/").pop();
    const id = Number(idStr);

    if (Number.isNaN(id)) {
      return Response.json(
        { error: "invalid id" },
        { status: 400 }
      );
    }

    const pool = await getPool();

    const result = await pool
      .request()
      .input("id", sql.Int, id)
      .query(`
        SELECT *
        FROM dbo.announcements
        WHERE id = @id
      `);

    if (result.recordset.length === 0) {
      return Response.json(
        { error: "ไม่พบข้อมูล" },
        { status: 404 }
      );
    }

    return Response.json(result.recordset[0]);
  } catch (error) {
    console.error("GET PUBLIC DETAIL ERROR:", error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

/* ===================== DELETE : ลบข่าว ===================== */
export async function DELETE(request) {
  try {
    const url = new URL(request.url);
    const idStr = url.pathname.split("/").pop();
    const id = Number(idStr);

    if (Number.isNaN(id)) {
      return Response.json(
        { error: "invalid id" },
        { status: 400 }
      );
    }

    const pool = await getPool();

    const result = await pool
      .request()
      .input("id", sql.Int, id)
      .query(`
        DELETE FROM dbo.announcements
        WHERE id = @id
      `);

    // กันกรณี id ไม่มีจริง
    if (result.rowsAffected[0] === 0) {
      return Response.json(
        { error: "ไม่พบข้อมูลที่จะลบ" },
        { status: 404 }
      );
    }

    return Response.json(
      { message: "ลบข่าวสำเร็จ" },
      { status: 200 }
    );
  } catch (error) {
    console.error("DELETE NEWS ERROR:", error);
    return Response.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
